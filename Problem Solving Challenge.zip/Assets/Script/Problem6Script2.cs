﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Problem6Script2 : MonoBehaviour
{
    public GameObject box;
    private void Start()
    {
        Invoke("Spawn", 1f);
    }

    public void Spawn()
    {

        float posX, posY;
        Vector2 pos;

        int numberToSpawn = Random.Range(1, 3);

        for (int i = 0; i < numberToSpawn; i++)
        {
            posX = Random.Range(1, 3);
            posY = Random.Range(3, -3);
            pos = new Vector2(posX, posY);

            Instantiate(box, pos, box.transform.rotation);
        }
    }
}