﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Problem9Script : MonoBehaviour
{
    public GameObject screen;

    private void OnTriggerEnter2D(Collider2D finish)
    {
        if(finish.name == "Finish")
        {
            screen.SetActive(true);
        }
    }
}
