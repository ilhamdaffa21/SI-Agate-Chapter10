﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Problem2Sphere : MonoBehaviour
{
    private Rigidbody2D sphere;
    public float xSpeed;
    public float ySpeed;
    void Start()
    {
        sphere = GetComponent<Rigidbody2D>();
        Invoke("Launch", 1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Launch()
    {
        float randomDir = Random.Range(1, 2);
        if (randomDir < 2)
        {
            sphere.AddForce(new Vector2(-xSpeed, ySpeed));
        }
        else
        {
            sphere.AddForce(new Vector2(xSpeed, ySpeed));
        }
    }
}
